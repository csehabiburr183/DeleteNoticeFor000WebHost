<?php 
/**
 * Plugin Name
 *
 * @package           Notice Delete 000Host
 * @author            Adnan Habib
 * @copyright         2021 By Adnan Habib
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Notice Delete 000WebHost
 * Plugin URI:        https://youtube.com/adnanhabib
 * Description:       Delete Unnecessary Notice For 000WebHost. Initial Release.
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Adnan Habib
 * Author URI:        https://youtube.com/adnanhabib
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

function NoticeDeleteHost(){
?>

<style type="text/css">
.notice.notice-error.is-dismissible {
    display: none !important;
    visibility: hidden;
}
</style>

<?php
}

add_action('admin_init','NoticeDeleteHost');

// Notice Removed

/* 
Remove Footer Logo From Dashboard And Front End UI
*/ 


function HostLogoDelForever(){
?>

<style type="text/css">
img[src="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"] {
    display: none;
}
</style>

<?php
}

add_action('init','HostLogoDelForever');







// End For Initial Release 